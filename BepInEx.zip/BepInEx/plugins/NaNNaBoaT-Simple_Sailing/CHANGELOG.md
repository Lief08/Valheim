## Release 1.1.0
- Updated to work with the new version of Valheim