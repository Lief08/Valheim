# Simple Sailing v1.1.0
##### by Wackjob
A straight forward wind mod that sets the wind direction behind the player when manning any boat.

I got tired of the hidden dev code that always seems to turn the wind against you when sailing, so I made this. This is a client-side mod and does not affect the wind direction for other players.

## Features
Wind:
- When using any boat, wind will always be at the player's back
